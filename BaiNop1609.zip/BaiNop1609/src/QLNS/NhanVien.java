package QLNS;

import java.util.*;
import static java.lang.String.*;
import static java.lang.System.*;

public class NhanVien extends NhanSu {
	private String tenTruongPhong; // ??? tên trưởng phòng
	private final float LUONG_NGAY = 100;
	private final Scanner sc = new Scanner(System.in);
	@Override
	public void tinhLuong() {
		luongThang = LUONG_NGAY * soNgayLamViec;
	}
	
	public void nhapTenTruongPhong() {
		System.out.println("Nhập tên trưởng phòng: ");
		tenTruongPhong = sc.nextLine();
	}
	
	
	@Override
	public void nhapNhanSu() {
		super.nhapNhanSu();
		nhapTenTruongPhong();
		tinhLuong();
	}
	
	public void xuatTenTruongPhong() {
		System.out.println("Mã trưởng phòng: " + tenTruongPhong);
	}
	
	@Override
	public void xuatLuongThang() {
		System.out.println("Lương tháng: " + luongThang);
	}
	
	@Override
	public void xuatNhanSu() {
		super.xuatMaNhanVien();
		super.xuatHoTen();
		super.xuatSoDienThoai();
		super.xuatChucVu();
		xuatTenTruongPhong();
		super.xuatSoNgayLamViec();
		xuatLuongThang();
	}
	
	// getter setter
	public String getTenTruongPhong() {
		return tenTruongPhong;
	}

	public void setTenTruongPhong(String tenTruongPhong) {
		this.tenTruongPhong = tenTruongPhong;
	}
	
}
