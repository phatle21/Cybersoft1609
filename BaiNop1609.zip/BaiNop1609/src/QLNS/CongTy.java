package QLNS;

// Main
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
//
import java.util.*;
import static java.util.Collections.*;
import static java.lang.Integer.*;
import static java.lang.String.*;
import static java.lang.System.*;
import static java.util.Collections.reverse;


public class CongTy {
	static Scanner m = new Scanner(System.in);

	// thêm nhân sự
		public static NhanSu themNhanSu(ArrayList<NhanSu> arrNhanSu) {
			var nhanSu = chonNhanSu();
			do {
				nhanSu.nhapMaNhanVien();
			}while(kiemTraMa(arrNhanSu, nhanSu.getMaNhanVien()));
			nhanSu.nhapNhanSu();
			return nhanSu;
	}
	// chọn nhân sự
		public static NhanSu chonNhanSu() {
			System.out.println("Chọn 1 trong 3 vị trí dưới đây: ");
			System.out.println("1.Nhân viên -- 2.Trưởng phòng -- 3.Giám đốc");
			int luaChon = m.nextInt();
			switch (luaChon) {
			case 1:
				return new NhanVien();
			case 2:
				return new TruongPhong();
			case 3:
				return new GiamDoc();
			default:
				return new NhanSu();
			}
		}
	
	// kiểm tra mã đã nhập chưa
	public static boolean kiemTraMa(ArrayList<NhanSu> arrNhanSu, String maNhanVien) {
		var daKiemTra = false;
		for(var nhanSu : arrNhanSu) {
			if(nhanSu.getMaNhanVien().equals(maNhanVien)) {
				System.out.println("Mã nhân viên đã tồn tại!");
				daKiemTra = true;
				break;
			}
		}
		return daKiemTra;
	}
	
	// kiểm tra trưởng phòng
	public static void kiemTraTruongPhong(ArrayList<NhanSu> arrNhanSu) {
		// nhân sự
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof NhanVien) {
				var nhanVien = (NhanVien) nhanSu;
				var isSuccess = false;
				// trưởng phòng
				for(var truongPhong : arrNhanSu) {
					if(truongPhong instanceof TruongPhong && 
							nhanVien.getTenTruongPhong().equals(truongPhong.getHoTen())) {
						isSuccess = true;
						break;
					}
				}
				if(!isSuccess) {
					nhanVien.setTenTruongPhong("");
				}
			}
		}
	}
	
	// đếm thành viên trong team
	public static void thanhVienTrongTeam(ArrayList<NhanSu> arrNhanSu) {
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof TruongPhong) {
				var truongPhong = ((TruongPhong) nhanSu);
				var dem = 0;
				for(var nhanVien : arrNhanSu) {
					if(nhanVien instanceof NhanVien &&
				((NhanVien) nhanVien).getTenTruongPhong().equals(truongPhong.getHoTen())) {
						dem++;
					}
				}
				truongPhong.setSoThanhVien(dem);
				truongPhong.tinhLuong();
			}
		}
	}
	
	// Tìm mã nhân viên
	public static int timMaNhanVien(ArrayList<NhanSu> arrNhanSu, String maNhanVien) {
		var index = -1; // false
		for(var i = 0 ; i < arrNhanSu.size(); i++) {
			if(arrNhanSu.get(i).getMaNhanVien().equals(maNhanVien)) {
				index = i;
				break;
			}
		}
		return index;
	}
	
	// Phân bổ nhân viên vào Trưởng phòng
	public static TruongPhong nhanVienChuyenThanhTruongPhong(NhanSu nhanSu) {
		// có thể để ở đây NhanSu nhanSu;
		var truongPhong = new TruongPhong();
		truongPhong.setMaNhanVien(nhanSu.getMaNhanVien());
		truongPhong.setHoTen(nhanSu.getHoTen());
		truongPhong.setSoDienThoai(nhanSu.getSoDienThoai());
		truongPhong.setSoNgayLamViec(nhanSu.getSoNgayLamViec());
		truongPhong.setSoThanhVien(0); // do mới chuyển
		truongPhong.tinhLuong();
		return truongPhong;
	}
	
	// Tổng lương
	public static float tongLuongCongTy(ArrayList<NhanSu> arrNhanSu) {
		float sum = 0;
		for(var nhanSu : arrNhanSu) {
			sum += nhanSu.getLuongThang();
		}
		return sum;
	}
	
	// Lương cao nhất
	public static ArrayList<NhanSu> timLuongCaoNhat(ArrayList<NhanSu> arrNhanSu){
		// tìm lương cao nhất
		var dsTopSalary = new ArrayList<NhanSu>();
		var maxSalary = arrNhanSu.get(0).getLuongThang();
		for(var nhanSu : arrNhanSu) {
			if(nhanSu.getLuongThang() > maxSalary) {
				maxSalary = nhanSu.getLuongThang();
			}
		}
		// thêm vào arraylist
		for(var nhanSu : arrNhanSu) {
			if(nhanSu.getLuongThang() == maxSalary) {
				dsTopSalary.add(nhanSu);
			}
		}
		return dsTopSalary;
	}
	
	// Trưởng phòng có nhiều nhân viên nhất
	public static ArrayList<TruongPhong> coNhieuNhanVien(ArrayList<NhanSu> arrNhanSu){
		// tìm max
		var dsTopTeam = new ArrayList<TruongPhong>();
		var maxTeam = 0;
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof TruongPhong) {
				var truongPhong = (TruongPhong) nhanSu;
				if(truongPhong.getSoThanhVien() > maxTeam) {
					maxTeam = truongPhong.getSoThanhVien();
				}
			}
		}
		// thêm vào arraylist
		for(var nhanSu : arrNhanSu) {
		if(nhanSu instanceof TruongPhong) {
			var truongPhong = (TruongPhong) nhanSu;
			if(truongPhong.getSoThanhVien() == maxTeam) {
				dsTopTeam.add(truongPhong);
				}
			}
		}
		return dsTopTeam;
	}
	
	// Sắp xếp nhân viên toàn công ty theo tên
	public static void sapXepTheoTen(ArrayList<NhanSu> arrNhanSu) {
		sort(arrNhanSu, new Comparator<NhanSu>() {
			@Override
			public int compare(NhanSu ns1, NhanSu ns2) {
				return ns1.getHoTen().compareTo(ns2.getHoTen());
			}
		});
	}
	
	// Sắp xếp nhân viên toàn công ty theo mã nhân viên 
	public static void sapXepTheoMaNhanVien(ArrayList<NhanSu> arrNhanSu) {
		sort(arrNhanSu, new Comparator<NhanSu>() {
			@Override
			public int compare(NhanSu ns1, NhanSu ns2) {
				return ns1.getMaNhanVien().compareTo(ns2.getMaNhanVien());
			}
		});
	}
	
	// Giám đốc có số lượng cổ phần nhiều nhất
	public static ArrayList<GiamDoc> timGiamDocCoCoPhanNhieuNhat(ArrayList<NhanSu> arrNhanSu){
		var dsTopShare = new ArrayList<GiamDoc>();
		double maxShare = 0; // 0d
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof GiamDoc) {
				var giamDoc = (GiamDoc) nhanSu;
				if(giamDoc.getCoPhan() > maxShare) {
					maxShare = giamDoc.getCoPhan();
				}
			}
		}
		// thêm vào arraylist
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof GiamDoc) {
				var giamDoc = (GiamDoc) nhanSu;
				if(giamDoc.getCoPhan() == maxShare) {
					dsTopShare.add(giamDoc);
				}
			}
		}
		return dsTopShare;
	}
	
	// tổng thu nhập từng giam đốc
	public static ArrayList<GiamDoc> thuNhapGiamDoc(ArrayList<NhanSu> arrNhanSu, float doanhThuThang){
		var dsGiamDoc = new ArrayList<GiamDoc>();
		var loiNhuan = doanhThuThang - tongLuongCongTy(arrNhanSu);
		for(var nhanSu : arrNhanSu) {
			if(nhanSu instanceof GiamDoc) {
				var giamDoc = (GiamDoc) nhanSu;
				giamDoc.setThuNhap(
						giamDoc.getLuongThang() + giamDoc.getCoPhan() * loiNhuan / 100);
				dsGiamDoc.add(giamDoc);
			}
		}
		return dsGiamDoc;
	}
	
	public static void main(String[] args) {
		// cho nhập có lúc lỗi lúc không
		arrNhanSu = new ArrayList<NhanSu>();
		System.out.println("---QUẢN LÝ NHÂN SỰ---");
		System.out.print("Nhập vào số thành viên: ");
		soThanhVien = sc.nextInt();
		System.out.println("\nNhập tên công ty: ");
		tenCongTy = sc.next();
		System.out.println("Nhập vào mã số thuế: ");
		maSoThue = sc.next();
		System.out.print("\nNhập doanh thu tháng: ");
		doanhThuThang = sc.nextFloat();
		for(int i = 0 ; i < soThanhVien ; i++) {
			System.out.println("Thành viên thứ " + (i+1) + " : ");
		arrNhanSu.add(themNhanSu(arrNhanSu));
		}
		// process
		kiemTraTruongPhong(arrNhanSu);
		thanhVienTrongTeam(arrNhanSu);
        // run
        chayChuongTrinh();
	
	}
		// fields 
		private static final Scanner sc = new Scanner(System.in);
		private static int soThanhVien;
		private static String tenCongTy;
		private static String maSoThue;
		private static float doanhThuThang;
		private static ArrayList<NhanSu> arrNhanSu;
		private static int luaChon;
			
		// Main
		private static void chayChuongTrinh() {					
			System.out.println(" 1. Bổ nhiệm nhân viên làm trưởng phòng");
			System.out.println(" 2. Thêm nhân sự ");
			System.out.println(" 3. Xóa nhân sự ");
			System.out.println(" 4. Xuất thông tin toàn bộ công ty ");
			System.out.println(" 5. Tính tổng lương toàn công ty ");
			System.out.println(" 6. Tìm thành viên có lương cao nhất ");
			System.out.println(" 7. Tìm trưởng phòng quản lý nhiều nhất");
			System.out.println(" 8. Sắp xếp nhân sự theo tên ");
			System.out.println(" 9. Sắp xếp nhân sự giảm dần ");
			System.out.println("10. Tìm giám đốc có cổ phần nhiều nhất ");
			System.out.println("11. Tính tổng thu nhập của mỗi giám đốc");
			System.out.println("--Chọn trong các điều kiện trên--");
			luaChon = sc.nextInt();
			switch (luaChon) {
			case 1:
				cauMot();
				break;
			case 2:
				cauHai();
				break;
			case 3:
				cauBa();
				break;
			case 4:
				cauBon();
				break;
			case 5:
				cauNam();
				break;
			case 6:
				cauSau();
				break;
			case 7:
				cauBay();
				break;
			case 8:
				cauTam();
				break;
			case 9:
				cauChin();
				break;
			case 10:
				cauMuoi();
				break;
			case 11:
				cauMuoiMot();
				break;
			default:
				System.out.println("Nhập sai câu");
				break;
			}
		}
		
		// xem thông tin công ty
		private static void thongTinCongTy() {
			System.out.println("Tên công ty: " + tenCongTy);
			System.out.println("Mã số thuế: " + maSoThue);
			System.out.println("Doanh thu tháng: " + doanhThuThang);
		}
		
		// bổ nhiệm nhân viên làm trưởng phòng
		private static void cauMot() {
			// 	
			var dsNhanVien = new ArrayList<NhanVien>();
			for(var nhanSu : arrNhanSu) {
				if(nhanSu instanceof NhanVien) {
					dsNhanVien.add((NhanVien) nhanSu);
				}
			}
			var max = dsNhanVien.size();
			if(max > 0) {
				System.out.println("Danh sách nhân viên: ");
				for(var i = 0 ; i < max ; i++) {
					var nhanVien = dsNhanVien.get(i);
					System.out.println("Thành viên thứ : " + (i+1) + " , họ tên: " + nhanVien.getHoTen() + " , mã nhân viên: " 
					+ nhanVien.getMaNhanVien());
				}
				System.out.println("Chọn 1 trong ");
				var index = timMaNhanVien(arrNhanSu, dsNhanVien.get(numLimit(1, max)- 1).getMaNhanVien());
				arrNhanSu.add(index, nhanVienChuyenThanhTruongPhong(arrNhanSu.get(index)));
				arrNhanSu.remove(index+1);
				thanhVienTrongTeam(arrNhanSu);
				cauBon();
			}else {
				thongTinCongTy();
				System.out.println("Công ty không có nhân viên nào!!!");
			}
		}
		
		// thêm nhân sự
		private static void cauHai() {
			System.out.println("Thêm thành viên mới: ");
			arrNhanSu.add(themNhanSu(arrNhanSu));
			thanhVienTrongTeam(arrNhanSu);
			cauBon();
		}
		public static int numLimit(int min, int max) {
			int n = sc.nextInt();
			if(n < min || n > max) {
				System.out.println("Sai , Xin nhập lại: ");
				n = numLimit(min, max);
			}
			return n;
		}
		
		// xóa nhân sự
		private static void cauBa() {
			System.out.println("Danh sách nhân viên: ");
			var max = arrNhanSu.size();
			for(var i = 0 ; i < max ; i++) {
				var nhanSu = arrNhanSu.get(i);
				//System.out.format("%d. %s (%s)", i+1 , nhanSu.getHoTen(), nhanSu.getMaNhanVien());
				System.out.println("Thành viên thứ : " + (i+1) + " , họ tên : " + nhanSu.getHoTen()
				+ " , mã nhân viên: " + nhanSu.getMaNhanVien());
			}
			System.out.println("Chỉ được chọn 1 nhân viên để xóa: ");
			var index = timMaNhanVien(arrNhanSu, arrNhanSu.get(numLimit(1, max) - 1).getMaNhanVien());
			arrNhanSu.remove(index);
			kiemTraTruongPhong(arrNhanSu);
			thanhVienTrongTeam(arrNhanSu);
			cauBon();
		}
		
		// thông tin toàn bộ công ty
		private static void cauBon() {
			thongTinCongTy();
			for(var nhanSu : arrNhanSu) {
				nhanSu.xuatNhanSu();
			}
		}
		
		// tổng lương toàn công ty
		private static void cauNam() {
			cauBon();
			System.out.format("Tổng lương toàn công ty : %.0f",tongLuongCongTy(arrNhanSu));
		}
		
		// thành viên lương cao nhất
		private static void cauSau() {
			thongTinCongTy();
			System.out.println("Thành viên lương cao nhất: ");
			var dsTopSalary = timLuongCaoNhat(arrNhanSu);
			for(var topNhanSu : dsTopSalary) {
				topNhanSu.xuatMaNhanVien();
				topNhanSu.xuatHoTen();
				topNhanSu.xuatChucVu();
				topNhanSu.xuatLuongThang();
			}
		}
		
		// trưởng phòng quản lý nhiều nhất
		private static void cauBay() {
			thongTinCongTy();
			System.out.println("Trưởng phòng quản lý nhiều nhân viên nhất: ");
			var dsTopTeam = coNhieuNhanVien(arrNhanSu);
			for(var topTruongPhong : dsTopTeam) {
				topTruongPhong.xuatHoTen();
				topTruongPhong.xuatsoThanhVien();
			}
		}
		
		// sắp xếp nhân sự theo tên
		private static void cauTam() {
			thongTinCongTy();
			System.out.println("Sắp xếp nhân sự theo tên: ");
			var dsNhanSu = new ArrayList<NhanSu>(arrNhanSu);
			sapXepTheoTen(arrNhanSu);
			for(var nhanSu : arrNhanSu) {
				nhanSu.xuatNhanSu();
			}
		}
		
		// sắp xếp nhân sự giảm dần
		private static void cauChin() {
			thongTinCongTy();
			System.out.println("Sắp xếp nhân sự giảm dần: ");
			var dsNhanSu = new ArrayList<NhanSu>(arrNhanSu);
			sapXepTheoMaNhanVien(dsNhanSu);
			reverse(dsNhanSu);
			for(var nhanSu : dsNhanSu) {
				nhanSu.xuatNhanSu();
			}
		}
		// tìm giám đốc có cổ phần nhiều nhất
		private static void cauMuoi() {
			thongTinCongTy();
			System.out.println("Giám đốc có nhiều cổ phần nhất là ");
			var dsTopShare = timGiamDocCoCoPhanNhieuNhat(arrNhanSu);
			for(var topGiamDoc : dsTopShare) {
				topGiamDoc.xuatHoTen();
				topGiamDoc.xuatCoPhan();
			}
		}
		// tổng thu nhập của mỗi giám đốc
		private static void cauMuoiMot() {
			thongTinCongTy();
			System.out.println("Thu nhập giám đốc là ");
			var dsGiamDoc = thuNhapGiamDoc(arrNhanSu, doanhThuThang);
			for(var topGiamDoc : dsGiamDoc) {
				topGiamDoc.xuatHoTen();
				topGiamDoc.xuatThuNhap();
			}
		}

}
