package QLNS;

import java.util.Scanner;
import java.util.*;
import static java.lang.String.*;
import static java.lang.System.*;
public class NhanSu {
	private String maNhanVien;
	private String hoTen;
	private int soDienThoai;
	protected double soNgayLamViec;
	protected double luongThang;
	private final String CHUC_VU = "Nhân viên";
	private final Scanner sc = new Scanner(System.in);
	
	// constructor
	public void tinhLuong() {
		luongThang = 0;
	}
	// chia nhỏ phần nhập 
	public void nhapMaNhanVien() {
		System.out.println("Nhập mã nhân viên: ");
		maNhanVien = sc.nextLine();
	}
	public void nhapHoTen() {
		System.out.println("Nhập họ tên nhân viên: ");
		hoTen = sc.nextLine();
	}
	public void nhapSoDienThoai() {
		System.out.println("Nhập số điện thoại: ");
		soDienThoai = sc.nextInt();
	}
	public void nhapSoNgayLamViec() {
//		do {
//			System.out.println("Nhập số ngày làm việc: ");
//		}while(soNgayLamViec >= 0 || soNgayLamViec <= 31);
		System.out.println("Nhập số ngày làm việc: ");
		soNgayLamViec = sc.nextDouble();
		
	}
	public void nhapNhanSu() {
		nhapHoTen();
		nhapSoDienThoai();
		nhapSoNgayLamViec();
	}
	public void xuatMaNhanVien() {
		System.out.println("Mã nhân viên: " + maNhanVien);
	}
	public void xuatHoTen() {
		System.out.println("Họ tên nhân viên: " + hoTen);
	}
	public void xuatSoDienThoai() {
		System.out.println("Số điện thoại: " + soDienThoai);
	}
	public void xuatSoNgayLamViec() {
		System.out.println("Số ngày làm việc: " + soNgayLamViec);
	}
	public void xuatLuongThang() {
		System.out.println("Lương tháng: " + luongThang);
	}
	public void xuatChucVu() {
		System.out.println("Chức vụ: " + CHUC_VU);
	}
	public void xuatNhanSu() {
		xuatMaNhanVien();
		xuatHoTen();
		xuatSoDienThoai();
		xuatChucVu();
		xuatSoNgayLamViec();
	}
	
	// getter , setter
	public String getMaNhanVien() {
		return maNhanVien;
	}
	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public int getSoDienThoai() {
		return soDienThoai;
	}
	public void setSoDienThoai(int soDienThoai) {
		this.soDienThoai = soDienThoai;
	}
	public double getSoNgayLamViec() {
		return soNgayLamViec;
	}
	public void setSoNgayLamViec(double soNgayLamViec) {
		this.soNgayLamViec = soNgayLamViec;
	}
	public double getLuongThang() {
		return luongThang;
	}

}
