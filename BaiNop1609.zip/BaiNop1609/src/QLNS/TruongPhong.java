package QLNS;

import static java.lang.String.*;

public class TruongPhong extends NhanSu{
	private int soThanhVien;
	private final String CHUC_VU = "Trưởng phòng";
	private final double LUONG_NGAY = 200;
	
	@Override
	public void tinhLuong() {
		luongThang = soNgayLamViec * LUONG_NGAY + 100 * soThanhVien;
	}
	public void xuatsoThanhVien() {
		System.out.println("Số thành viên: " + soThanhVien);
	}
	@Override 
	public void xuatChucVu() {
		System.out.println("Chức vụ: " + CHUC_VU);
	}
	@Override
	public void xuatLuongThang() {
		System.out.println("Lương tháng: " + luongThang);
	}
	@Override
	public void xuatNhanSu() {
		super.xuatMaNhanVien();
		super.xuatHoTen();
		super.xuatSoDienThoai();
		xuatChucVu();
		xuatsoThanhVien();
		super.xuatSoNgayLamViec();
		xuatLuongThang();
	}
	
	// getter , setter
	public int getSoThanhVien() {
		return soThanhVien;
	}
	public void setSoThanhVien(int soThanhVien) {
		this.soThanhVien = soThanhVien;
	}

}
