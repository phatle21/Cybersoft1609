package QLNS;

import static java.lang.Double.*;
import static java.lang.String.*;

import java.util.Scanner;

public class GiamDoc extends NhanSu {
	private double coPhan;
	private double thuNhap;
	private final String CHUC_VU = "Giám đốc";
	private final double LUONG_NGAY = 300;
	private final Scanner sc = new Scanner(System.in);

	@Override
	public void tinhLuong() {
		luongThang = soNgayLamViec * LUONG_NGAY;
	}
	public void nhapCoPhan() {
		System.out.println("Nhập số cổ phần: ");
		coPhan = sc.nextInt();
	}
	@Override
	public void nhapNhanSu() {
		super.nhapNhanSu();
		nhapCoPhan();
		tinhLuong();
	}
	public void xuatCoPhan() {
		System.out.println("Số lượng cổ phần: " + coPhan);
	}
	public void xuatThuNhap() {
		System.out.println("Thu nhập: " + thuNhap);
	}
	@Override
	public void xuatChucVu() {
		System.out.println("Chức vụ: " + CHUC_VU);
	}
	@Override 
	public void xuatLuongThang() {
		System.out.println("Lương tháng: " + luongThang);
	}
	@Override
	public void xuatNhanSu() {
		super.xuatMaNhanVien();
		super.xuatHoTen();
		super.xuatSoDienThoai();
		xuatChucVu();
		xuatCoPhan();
		super.xuatSoNgayLamViec();
		xuatLuongThang();
	}
	// getter , setter
	public double getCoPhan() {
		return coPhan;
	}
	public void setCoPhan(int coPhan) {
		this.coPhan = coPhan;
	}
	public double getThuNhap() {
		return thuNhap;
	}
	public void setThuNhap(double thuNhap) {
		this.thuNhap = thuNhap;
	}
	
}
